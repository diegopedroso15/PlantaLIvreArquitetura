#include "../include/audio_asset.h"

dbasic::AudioAsset::AudioAsset() {
    m_buffer = nullptr;
}

dbasic::AudioAsset::~AudioAsset() {
    /* void */
}
