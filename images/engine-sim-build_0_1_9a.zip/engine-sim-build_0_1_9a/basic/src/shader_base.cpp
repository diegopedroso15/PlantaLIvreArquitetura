#include "../include/shader_base.h"

dbasic::ShaderBase::ShaderBase() {
	/* void */
}

dbasic::ShaderBase::~ShaderBase() {
	/* void */
}
