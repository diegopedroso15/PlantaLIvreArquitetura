#ifndef DELTA_BASIC_FONT_MAP_H
#define DELTA_BASIC_FONT_MAP_H

namespace dbasic {

    extern int FONT_MAP[256];
    extern const int BOLD_OFFSET;

    void InitializeFontMap();

} /* namesapce dbasic */

#endif /* DELTA_BASIC_FONT_MAP_H */
