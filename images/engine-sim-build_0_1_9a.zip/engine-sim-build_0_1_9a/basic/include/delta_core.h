#ifndef DELTA_BASIC_DELTA_CORE_H
#define DELTA_BASIC_DELTA_CORE_H

#include "../../../include/yds_core.h"

#endif /* DELTA_BASIC_DELTA_CORE_H */
