#ifndef DELTA_BASIC_OS_UTILITIES_H
#define DELTA_BASIC_OS_UTILITIES_H

#include "path.h"

namespace dbasic {

    Path GetModulePath();

} /* namespace dbasic */

#endif /* DELTA_BASIC_OS_UTILITIES_H */
