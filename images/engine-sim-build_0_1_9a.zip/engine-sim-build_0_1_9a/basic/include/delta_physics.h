#ifndef DELTA_BASIC_DELTA_PHYSICS_H
#define DELTA_BASIC_DELTA_PHYSICS_H

#include "../../../physics/include/delta_physics.h"

#endif /* DELTA_BASIC_DELTA_PHYSICS_H */
